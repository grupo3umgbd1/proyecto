drop index IND_ESMPR;

drop table ESMPR cascade constraints;

/*==============================================================*/
/* Table: ESMPR                                                 */
/*==============================================================*/
create table ESMPR 
(
   ESMPRIDENTITY        NUMBER               not null,
   IND_ESMPR            as (case when (-1)<ESMPRIDENTITY AND ESTADO <> 'N' then 0 else ESMPRIDENTITY end),
   IDPERSONA            number(10)           not null,
   IDCOLOR              number(2),
   PRIMERNOMBRE         VARCHAR2(50),
   SEGUNDONOMBRE        VARCHAR2(50),
   TERCERNOMBRE         VARCHAR2(50),
   PRIMERAPELLIDO       VARCHAR2(50),
   SEGUNDOAPELLIDO      VARCHAR2(50),
   APELLIDOCASADA       VARCHAR2(50),
   FECHANACIMIENTO      DATE,
   GENERO               VARCHAR2(1),
   ESTADO               VARCHAR2(1),
   constraint PK_ESMPR primary key (ESMPRIDENTITY)
);

/*==============================================================*/
/* Index: IND_ESMPR                                             */
/*==============================================================*/
create unique index IND_ESMPR on ESMPR (
   IND_ESMPR ASC,
   IDPERSONA ASC
);


comment on table ESMPR is
'Maestro de personas';

CREATE SEQUENCE SEQ_ESMPR
 START WITH 1
 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER TRG_BIR_ESMPR BEFORE INSERT /*BEFORE INSERT RECORD*/
ON ESMPR
FOR EACH ROW
BEGIN
    SELECT SEQ_ESMPR.NEXTVAL INTO :NEW.ESMPRIDENTITY FROM DUAL;
END;