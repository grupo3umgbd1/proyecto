drop index IND_ESRLT;

drop table ESRLT cascade constraints;

/*==============================================================*/
/* Table: ESRLT                                                 */
/*==============================================================*/
create table ESRLT 
(
   ESRLTIDENTITY        NUMBER               not null,
   IND_ESRLT            as (case when (-1)<ESRLTIDENTITY AND ESTADO <> 'N' then 0 else ESRLTIDENTITY end),
   IDLISTA              NUMBER,
   IDTRX                NUMBER,
   ESTADO               VARCHAR2(1),
   constraint PK_ESRLT primary key (ESRLTIDENTITY)
);

/*==============================================================*/
/* Index: IND_ESRLT                                             */
/*==============================================================*/
create unique index IND_ESRLT on ESRLT (
   IND_ESRLT ASC,
   IDLISTA ASC,
   IDTRX ASC
);


CREATE SEQUENCE SEQ_ESRLT
 START WITH 1
 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER TRG_BIR_ESRLT BEFORE INSERT /*BEFORE INSERT RECORD*/
ON ESRLT
FOR EACH ROW
BEGIN
    SELECT SEQ_ESRLT.NEXTVAL INTO :NEW.ESRLTIDENTITY FROM DUAL;
END;