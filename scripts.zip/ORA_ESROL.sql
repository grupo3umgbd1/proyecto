/*==============================================================*/
/* Table: ESROL                                                 */
/*==============================================================*/
create table ESROL 
(
   ESROLIDENTITY        number               not null,
   IND_ESROL            as (case when (-1)<ESROLIDENTITY AND ESTADO <> 'N' then 0 else ESROLIDENTITY end),
   IDROL                NUMBER,
   DESCRIPCION          VARCHAR2(60),
   ESTADO               VARCHAR2(1),
   constraint PK_ESROL primary key (ESROLIDENTITY)
);

/*==============================================================*/
/* Index: IND_ROL                                               */
/*==============================================================*/
create unique index IND_ESROL on ESROL (IND_ESROL ASC,IDROL ASC);

CREATE SEQUENCE SEQ_ESROL
 START WITH 1
 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER TRG_BIR_ESROL BEFORE INSERT /*BEFORE INSERT RECORD*/
ON ESROL
FOR EACH ROW
BEGIN
    SELECT SEQ_ESROL.NEXTVAL INTO :NEW.ESROLIDENTITY FROM DUAL;
END;