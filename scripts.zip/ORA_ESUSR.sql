drop table ESUSR cascade constraints;

/*==============================================================*/
/* Table: USUARIO                                               */
/*==============================================================*/
create table ESUSR 
(
   ESUSRIDENTITY        number               not null,
   IND_ESUSR            as (case when (-1)<ESUSRIDENTITY AND ESTATUS <> 'N' then 0 else ESUSRIDENTITY end),
   IDSUCURSAL           number,
   IDJORNADA            number,
   IDUSUARIO            number,
   USUARIO              varchar2(15),
   CLAVE                varchar2(30),
   IDROL                number,
   IDPERSONA            number,
   SESION               varchar2(50),
   EDOCONEXION          varchar2(3),
   FECHACREACION        varchar2(10),
   FECHAMOD             varchar2(10),
   FECHAULTINGRESO      varchar2(10),
   HORAULTINGRESO       varchar2(6),
   ESTATUS              varchar2(1),
   constraint PK_ESUSR primary key (ESUSRIDENTITY)
);

create unique index IND_ESUSR  on ESUSR (IND_ESUSR,USUARIO ASC);

CREATE SEQUENCE SEQ_ESUSR
 START WITH 1
 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER TRG_BIR_ESUSR BEFORE INSERT /*BEFORE INSERT RECORD*/
ON ESUSR
FOR EACH ROW
BEGIN
    SELECT SEQ_ESUSR.NEXTVAL INTO :NEW.ESUSRIDENTITY FROM DUAL;
END;