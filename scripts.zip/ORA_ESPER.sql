drop index IND_ESPER;

drop table ESPER cascade constraints;

/*==============================================================*/
/* Table: ESPER                                                 */
/*==============================================================*/
create table ESPER 
(
   ESPERIDENTITY        NUMBER,
   IND_ESPER            as (case when (-1)<ESPERIDENTITY AND ESTADO <> 'N' then 0 else ESPERIDENTITY end),
   IDPERFIL             NUMBER,
   DESCRIPCION          VARCHAR2(60),
   ESTADO               VARCHAR2(1)
);

/*==============================================================*/
/* Index: IND_ESPER                                             */
/*==============================================================*/
create unique index IND_ESPER on ESPER (
   IND_ESPER ASC,
   IDPERFIL ASC
);

CREATE SEQUENCE SEQ_ESPER
 START WITH 1
 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER TRG_BIR_ESPER BEFORE INSERT /*BEFORE INSERT RECORD*/
ON ESPER
FOR EACH ROW
BEGIN
    SELECT SEQ_ESPER.NEXTVAL INTO :NEW.ESPERIDENTITY FROM DUAL;
END;