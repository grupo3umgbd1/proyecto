drop index IND_ESMUN;

drop table ESMUN cascade constraints;

/*==============================================================*/
/* Table: ESMUN                                                 */
/*==============================================================*/
create table ESMUN 
(
   ESMUNIDENTITY        NUMBER               not null,
   IND_ESMUN            as (case when (-1)<ESMUNIDENTITY AND ESTADO <> 'N' then 0 else ESMUNIDENTITY end),
   IDPAIS               number(2),
   IDDEPARTAMENTO       number,
   IDMUNICIPIO          number(3),
   MUNICIPIO            VARCHAR2(50),
   ESTADO               VARCHAR2(1),
   constraint PK_ESMUN primary key (ESMUNIDENTITY)
);

/*==============================================================*/
/* Index: IND_ESMUN                                             */
/*==============================================================*/
create unique index IND_ESMUN on ESMUN (
   IND_ESMUN ASC,
   IDMUNICIPIO ASC
);

CREATE SEQUENCE SEQ_ESMUN
 START WITH 1
 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER TRG_BIR_ESMUN BEFORE INSERT /*BEFORE INSERT RECORD*/
ON ESMUN
FOR EACH ROW
BEGIN
    SELECT SEQ_ESMUN.NEXTVAL INTO :NEW.ESMUNIDENTITY FROM DUAL;
END;