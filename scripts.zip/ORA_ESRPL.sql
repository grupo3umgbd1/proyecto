drop index IND_ESRPL;

drop table ESRPL cascade constraints;

/*==============================================================*/
/* Table: ESRPL                                                 */
/*==============================================================*/
create table ESRPL 
(
   ESRPLIDENTITY        NUMBER               not null,
   IND_ESRPL            as (case when (-1)<ESRPLIDENTITY AND ESTADO <> 'N' then 0 else ESRPLIDENTITY end),
   IDPERFIL             NUMBER,
   IDLISTA              NUMBER,
   ESTADO               VARCHAR2(1),
   constraint PK_ESRPL primary key (ESRPLIDENTITY)
);

/*==============================================================*/
/* Index: IND_ESRPL                                             */
/*==============================================================*/
create unique index IND_ESRPL on ESRPL (
   IND_ESRPL ASC,
   IDPERFIL ASC,
   IDLISTA ASC
)

CREATE SEQUENCE SEQ_ESRPL
 START WITH 1
 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER TRG_BIR_ESRPL BEFORE INSERT /*BEFORE INSERT RECORD*/
ON ESRPL
FOR EACH ROW
BEGIN
    SELECT SEQ_ESRPL.NEXTVAL INTO :NEW.ESRPLIDENTITY FROM DUAL;
END;