drop index IND_ESMPA;

drop table ESMPA cascade constraints;

/*==============================================================*/
/* Table: ESMPA                                                 */
/*==============================================================*/
create table ESMPA 
(
   ESMPAIDENTITY        number               not null,
   IND_ESMPA            as (case when (-1)<ESMPAIDENTITY AND ESTADO <> 'N' then 0 else ESMPAIDENTITY end),
   IDPAIS               number,
   PAIS                 varchar2(60),
   ESTADO               varchar2(1),
   constraint PK_ESMPA primary key (ESMPAIDENTITY)
);

/*==============================================================*/
/* Index: IND_ESMPA                                             */
/*==============================================================*/
create unique index IND_ESMPA on ESMPA (
   IND_ESMPA ASC,
   IDPAIS ASC
);

CREATE SEQUENCE SEQ_ESMPA
 START WITH 1
 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER TRG_BIR_ESMPAS BEFORE INSERT /*BEFORE INSERT RECORD*/
ON ESMPA
FOR EACH ROW
BEGIN
    SELECT SEQ_ESMPA.NEXTVAL INTO :NEW.ESMPAIDENTITY FROM DUAL;
END;