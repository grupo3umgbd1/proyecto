drop index IND_ESTRX;

drop table ESTRX cascade constraints;

/*==============================================================*/
/* Table: ESTRX                                                 */
/*==============================================================*/
create table ESTRX 
(
   ESTRXIDENTITY        NUMBER               not null,
   IND_ESTRX            as (case when (-1)<ESTRXIDENTITY AND ESTADO <> 'N' then 0 else ESTRXIDENTITY end),
   IDTRX                NUMBER,
   NOMBRE               VARCHAR2(60),
   ESTADO               VARCHAR2(60),
   constraint PK_ESTRX primary key (ESTRXIDENTITY)
);

/*==============================================================*/
/* Index: IND_ESTRX                                             */
/*==============================================================*/
create unique index IND_ESTRX on ESTRX (
   IND_ESTRX ASC,
   IDTRX ASC
);

CREATE SEQUENCE SEQ_ESTRX
 START WITH 1
 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER TRG_BIR_ESTRX BEFORE INSERT /*BEFORE INSERT RECORD*/
ON ESTRX
FOR EACH ROW
BEGIN
    SELECT SEQ_ESTRX.NEXTVAL INTO :NEW.ESTRXIDENTITY FROM DUAL;
END;