drop index IND_ESLTS;

drop table ESLTS cascade constraints;

/*==============================================================*/
/* Table: ESLTS                                                 */
/*==============================================================*/
create table ESLTS 
(
   ESLTSIDENTITY        NUMBER               not null,
   IND_ESLTS            as (case when (-1)<ESLTSIDENTITY AND ESTADO <> 'N' then 0 else ESLTSIDENTITY end),
   IDLISTA              NUMBER,
   DESCRIPCION          VARCHAR2(60),
   ESTADO               VARCHAR2(1),
   constraint PK_ESLTS primary key (ESLTSIDENTITY)
);

comment on table ESLTS is
'Maestro de listas';

/*==============================================================*/
/* Index: IND_ESLTS                                             */
/*==============================================================*/
create unique index IND_ESLTS on ESLTS (
   IND_ESLTS ASC,
   IDLISTA ASC
);


CREATE SEQUENCE SEQ_ESLTS
 START WITH 1
 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER TRG_BIR_ESLTS BEFORE INSERT /*BEFORE INSERT RECORD*/
ON ESLTS
FOR EACH ROW
BEGIN
    SELECT SEQ_ESLTS.NEXTVAL INTO :NEW.ESLTSIDENTITY FROM DUAL;
END;