drop index IND_ESRRP;

drop table ESRRP cascade constraints;

/*==============================================================*/
/* Table: ESRRP                                                 */
/*==============================================================*/
create table ESRRP 
(
   ESRRPIDENTITY        NUMBER               not null,
   IND_ESRRP            as (case when (-1)<ESRRPIDENTITY AND ESTADO <> 'N' then 0 else ESRRPIDENTITY end),
   IDROL                NUMBER,
   IDPERFIL             NUMBER,
   ESTADO               VARCHAR2(1),
   constraint PK_ESRRP primary key (ESRRPIDENTITY)
);

comment on table ESRRP is
'Relacion de rol / perfil';

/*==============================================================*/
/* Index: IND_ESRRP                                             */
/*==============================================================*/
create unique index IND_ESRRP on ESRRP (
   IND_ESRRP ASC,
   IDROL ASC,
   IDPERFIL ASC
);

CREATE SEQUENCE SEQ_ESRRP
 START WITH 1
 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER TRG_BIR_ESRRP BEFORE INSERT /*BEFORE INSERT RECORD*/
ON ESRRP
FOR EACH ROW
BEGIN
    SELECT SEQ_ESRRP.NEXTVAL INTO :NEW.ESRRPIDENTITY FROM DUAL;
END;