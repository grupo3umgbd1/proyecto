drop index IND_ESMDP;

drop table ESMDP cascade constraints;

/*==============================================================*/
/* Table: ESMDP                                                 */
/*==============================================================*/
create table ESMDP 
(
   ESMDPIDENTITY        NUMBER               not null,
   IND_ESMDP            as (case when (-1)<ESMDPIDENTITY AND ESTADO <> 'N' then 0 else ESMDPIDENTITY end),
   IDPAIS               number(3),
   IDDEPARTAMENTO       number(2),
   DEPARTAMENTO         VARCHAR2(50),
   ESTADO               VARCHAR2(1),
   constraint PK_ESMDP primary key (ESMDPIDENTITY)
);

/*==============================================================*/
/* Index: IND_ESMDP                                             */
/*==============================================================*/
create unique index IND_ESMDP on ESMDP (
   IND_ESMDP ASC,
   IDPAIS ASC,
   IDDEPARTAMENTO ASC
);

CREATE SEQUENCE SEQ_ESMDP
 START WITH 1
 INCREMENT BY 1;

CREATE OR REPLACE TRIGGER TRG_BIR_ESMDP BEFORE INSERT /*BEFORE INSERT RECORD*/
ON ESMDP
FOR EACH ROW
BEGIN
    SELECT SEQ_ESMDP.NEXTVAL INTO :NEW.ESMDPIDENTITY FROM DUAL;
END;